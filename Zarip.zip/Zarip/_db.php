<?php

// use sqlite
require_once 'mysqli.php';

// use MySQL
//require_once '_db_mysql.php';